﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;

namespace AP_AI_DevOps.Controllers
{
    public class CreateEpicController : Controller
    {
        private static readonly string OrganizationName = "APCollections";
        private static readonly string ProjectName = "AP_AI_Dev";
        private static readonly string PersonalAccessToken = "6N5T3hPG1WnmaEHcPBCr6yYYyBjjyFj3gSgaZuL1eOmBEa7CFIj5JQQJ99BCACAAAAAoySsEAAASAZDO3LqR";
        private static readonly string workItemType = "Epic";
        private static readonly string WorkItemApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workitems/${workItemType}?api-version=6.0";
        // GET: CreateEpic
        public ActionResult Index()
        {
            return View();
        }

        // GET: CreateEpic/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        /// <summary>
        /// Load View for Create EPIC
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// POST: CreateEpic/Create
        /// </summary>
        /// <param name="collection"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        /// <summary>
        ///   call for create new EPIC on DDL EPIC selection 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CreateEpic(string title, string description)
        {
            await CreateEpicin(title, description);
            // Redirect to the About action in the Home controller
            return RedirectToAction("About", "Home");
        }

        // C#
        private static async Task CreateEpicin(string title, string description)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
                    "Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($":{PersonalAccessToken}")));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var patchContent = new StringContent(
                    "[ " +
                    "{ \"op\": \"add\", \"path\": \"/fields/System.Title\", \"value\": \"" + title + "\" }, " +
                    "{ \"op\": \"add\", \"path\": \"/fields/System.Description\", \"value\": \"" + description + "\" }, " +
                    "{ \"op\": \"add\", \"path\": \"/fields/System.AreaPath\", \"value\": \"" + ProjectName + "\" }, " +
                    "{ \"op\": \"add\", \"path\": \"/fields/System.IterationPath\", \"value\": \"" + ProjectName + "\" } " +
                    "]",
                    System.Text.Encoding.UTF8,
                    "application/json-patch+json");

                var method = new HttpMethod("PATCH");
                var request = new HttpRequestMessage(method, WorkItemApiUrl) { Content = patchContent };
                var response = await client.SendAsync(request);

                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Work item created successfully");
                }
                else
                {
                    var errorDetails = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Error: {response.StatusCode} - {errorDetails}");
                }
            }
        }


        // GET: CreateEpic/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CreateEpic/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: CreateEpic/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: CreateEpic/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

    }
}
