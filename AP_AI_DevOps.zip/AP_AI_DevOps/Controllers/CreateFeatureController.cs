// C#
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;

namespace AP_AI_DevOps.Controllers
{
    public class CreateFeatureController : Controller
    {

        private static readonly string OrganizationName = "APCollections";
        private static readonly string ProjectName = "AP_AI_Dev";
        private static readonly string PersonalAccessToken = "6N5T3hPG1WnmaEHcPBCr6yYYyBjjyFj3gSgaZuL1eOmBEa7CFIj5JQQJ99BCACAAAAAoySsEAAASAZDO3LqR";
        private static readonly string workItemType = "Feature";
        private static readonly string WorkItemApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workitems/${workItemType}?api-version=6.0";
        // GET: CreateFeature/Create
        public ActionResult Create()
        {
            // Optionally, populate ViewBag or ViewModel for the view
            return View();
        }

        // POST: CreateFeature/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(string featureName)
        {
            if (!string.IsNullOrEmpty(featureName))
            {
                // Save the new feature (add your logic here)
                // Redirect or show success message
                return RedirectToAction("About", "Home");
            }
            // If invalid, return the view with error
            ViewBag.Error = "Feature name is required.";
            return View();
        }

        /// <summary>
        ///   call for create new EPIC on DDL EPIC selection 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> CreateFeature(string title, string description, int epicid)
        {
            //await CreateFeaturein(title, description);
            await CreateFeatureinEpic(title, description, epicid);
            // Redirect to the About action in the Home controller
            return RedirectToAction("About", "Home");
        }

        private static async Task CreateFeaturein(string title, string description)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($":{PersonalAccessToken}")));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var patchContent = new StringContent(
                    "[ { \"op\": \"add\", \"path\": \"/fields/System.Title\", \"value\": \"" + title + "\" }, { \"op\": \"add\", \"path\": \"/fields/System.Description\", \"value\": \"" + description + "\" } ]",
                    System.Text.Encoding.UTF8,
                    "application/json-patch+json");

                var response = await client.PostAsync(WorkItemApiUrl, patchContent);
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Work item created successfully");
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                }
            }
        }
        /// <summary>
        /// Create EPIC and Feature relation 
        /// </summary>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <param name="epicId"></param>
        /// <returns></returns>
        private static async Task CreateFeatureinEpic(string title, string description, int epicId)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes($":{PersonalAccessToken}")));
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var patchDocument = new List<object>
                    {
                        new { op = "add", path = "/fields/System.Title", value = title },
                        new { op = "add", path = "/fields/System.Description", value = description },
                        new {
                            op = "add",
                            path = "/relations/-",
                            value = new {
                                rel = "System.LinkTypes.Hierarchy-Reverse",
                                url = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workItems/{epicId}"
                            }
                        }
                    };

                var patchContent = new StringContent(
                    System.Text.Json.JsonSerializer.Serialize(patchDocument),
                    System.Text.Encoding.UTF8,
                    "application/json-patch+json");

                var response = await client.PostAsync(WorkItemApiUrl, patchContent);
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Work item created successfully");
                }
                else
                {
                    Console.WriteLine($"Error: {response.StatusCode}");
                }
            }
        }

        [HttpGet]
        public IActionResult Create(int epicId)
        {
            // Pass epicId to the view (e.g., via ViewBag or a ViewModel)
            ViewBag.EpicId = epicId;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(FeatureViewModel model)
        {
            // model.EpicId contains the selected Epic ID
            // Create the Feature and link it to the Epic
            await CreateFeatureinEpic(model.Title, model.Description, model.EpicId);
            return RedirectToAction("About", "Home");
        }
    }
}
