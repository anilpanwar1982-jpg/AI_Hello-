<<<<<<< HEAD
﻿using AP_AI_DevOps.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Azure.AI.OpenAI;
using OpenAI.Chat;
using Azure;
using System.ClientModel;
using System.IO;
using System.Text.RegularExpressions;
=======

using AP_AI_DevOps.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections;
using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json.Linq;
>>>>>>> 5236eb2 (Commit)

namespace AP_AI_DevOps.Controllers
{
    public class HomeController : Controller
    {
        private static readonly string OrganizationName = "APCollections";
        private static readonly string ProjectName = "AP_AI_Dev";
        private static readonly string PersonalAccessToken = "6N5T3hPG1WnmaEHcPBCr6yYYyBjjyFj3gSgaZuL1eOmBEa7CFIj5JQQJ99BCACAAAAAoySsEAAASAZDO3LqR"; // Make sure to replace this with your PAT
        //private static readonly string ApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_workitems";
        private static readonly string ApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/";
        string teamName = "AIAPTEAM"; // Replace with your actual team name
        private readonly ILogger<HomeController> _logger;
        private static readonly string workItemType = "Stories";
        private static readonly string WorkItemApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workitems/${workItemType}?api-version=6.0";

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public ActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
<<<<<<< HEAD

        /// <summary>
        /// return back to About
        /// </summary>
        /// <returns></returns>
        public async Task<ActionResult> About()
        {
            ViewBag.dropdown1 = await GetEpicsAsync(OrganizationName, ProjectName);

            ViewBag.dropdown2 = await GetFeatureAsync(OrganizationName, ProjectName);
            ViewBag.AssignedToList = await GetAzureDevOpsUsersAsync();
=======
        // C#
        public ActionResult About()
        {
            ViewBag.dropdown1 = new List<SelectListItem>
            {
                new SelectListItem { Text = "Option A", Value = "A" },
                new SelectListItem { Text = "Option B", Value = "B" },
                new SelectListItem { Text = "Option C", Value = "C" }
            };

            ViewBag.dropdown2 = new List<SelectListItem>
            {
                new SelectListItem { Text = "Option 1", Value = "1" },
                new SelectListItem { Text = "Option 2", Value = "2" },
                new SelectListItem { Text = "Option 3", Value = "3" }
            };
>>>>>>> 5236eb2 (Commit)

            return View();
        }

<<<<<<< HEAD
        /// <summary>
        /// Get the Team memebers details from Azure DevOps
        /// </summary>
        /// <returns></returns>
        private Task<List<SelectListItem>> GetAzureDevOpsUsersAsync()
        {
            var users = new List<SelectListItem>
            {
                new SelectListItem { Value = "anil.r.kumar@capgemini.com", Text = "Anil Panwar" },
                new SelectListItem { Value = "mohd-mudashshir.ahmad@capgemini.com", Text = "Mohd Mudashshir" },
                new SelectListItem { Value = "shailendu.dwivedi@capgemini.com", Text = "Shailendu Diwedi" },
                new SelectListItem { Value = "shreya.d.srivastava@capgemini.com", Text = "Shreya Sri" }
            };
            return Task.FromResult(users);
        }

        /// <summary>
        /// Get Team ID 
        /// </summary>
        /// <param name="organization"></param>
        /// <param name="project"></param>
        /// <param name="teamName"></param>
        /// <returns></returns>
        private async Task<string> GetTeamIdAsync(string organization, string project, string teamName)
        {
            var httpClient = new HttpClient();
            var teamsUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/teams?api-version=7.0";
            var response = await httpClient.GetAsync(teamsUrl);
            var json = await response.Content.ReadAsStringAsync();

            using var doc = JsonDocument.Parse(json);
            var teams = doc.RootElement.GetProperty("value");

            foreach (var team in teams.EnumerateArray())
            {
                var id = team.GetProperty("id").GetString();
                var name = team.GetProperty("name").GetString();
                Console.WriteLine($"{name} → {id}");
            }
            return null; // Team not found
        }

        /// <summary>
        /// Save the User story details 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<ActionResult> SaveUserStory(UserStoryModel model)
        {
            if (ModelState.IsValid)
            {
                CallOpenAI(model);

                model.UserStoryDescription = Formating(model.UserStoryDescription);
                string[] arrUserStoryDescription = SplitAfterAcceptanceCriteria(model.UserStoryDescription);                

                if (arrUserStoryDescription is { Length: 2 } && arrUserStoryDescription[0] is not null && arrUserStoryDescription[1] is not null)
                {
                    model.AcceptanceCriteria = arrUserStoryDescription[1];
                    model.UserStoryDescription = arrUserStoryDescription[0];
                }
                // Call CreateUserStoryAsync to create the user story in Azure DevOps
                int userStoryId = await CreateUserStoryAsync(
                    model.UserStoryTitle,
                    model.UserStoryDescription,
                    model.ParentId,      // Make sure your model has ParentId property
                    model.AssignedTo,
                    model.AcceptanceCriteria, model.Priority, model.StoryPoints
                );

                if (userStoryId > 0)
                {
                    _logger.LogInformation("User Story created with ID: {Id}", userStoryId);
                    ViewBag.GeneratedStory = $"User Story created successfully. ID: {userStoryId}<br/>{model.UserStoryDescription}";
                }
                else
                {
                    ViewBag.GeneratedStory = $"Failed to create User Story.<br/>{model.UserStoryDescription}";
                }
            }
            else
            {
                ViewBag.GeneratedStory = "Invalid data";
            }

            ViewBag.dropdown1 = await GetEpicsAsync(OrganizationName, ProjectName);
            ViewBag.dropdown2 = await GetFeatureAsync(OrganizationName, ProjectName);
            ViewBag.AssignedToList = await GetAzureDevOpsUsersAsync();
            return View("About");
        }

        /// <summary>
        /// Calling open AI for User Story generation
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        private static void CallOpenAI(UserStoryModel model)
        {
            string strmsg = string.Empty;
            AzureOpenAIClient azureClient = new(new Uri("https://apcgtt.services.ai.azure.com/"), new AzureKeyCredential("F7qZiq7kQz3jlp8VeSt1YkbZKybXf5GApeOgCSTSq50BLN15TptWJQQJ99BBACYeBjFXJ3w3AAAAACOGY4Pd"));
            ChatClient chatClient = azureClient.GetChatClient("gpt-4o");

            // Prepare prompt
            string prompt = $"Generate a user story for description: {model.UserStoryDescription} step by step tasks and final acceptance criteria";

            CollectionResult<StreamingChatCompletionUpdate> completionUpdates = chatClient.CompleteChatStreaming(
                   [
                         new UserChatMessage(prompt),
                      ]);

            foreach (StreamingChatCompletionUpdate completionUpdate in completionUpdates)
            {
                foreach (ChatMessageContentPart contentPart in completionUpdate.ContentUpdate)
                {
                    strmsg += contentPart.Text;
                }
            }

            model.UserStoryDescription = strmsg;
        }
=======

        private static readonly string OrganizationName = "APCollections";
        private static readonly string ProjectName = "GenAI-POC-AP";
        private static readonly string PersonalAccessToken = "6N5T3hPG1WnmaEHcPBCr6yYYyBjjyFj3gSgaZuL1eOmBEa7CFIj5JQQJ99BCACAAAAAoySsEAAASAZDO3LqR"; // Make sure to replace this with your PAT
        //private static readonly string ApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_workitems";
        private static readonly string ApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/";

>>>>>>> 5236eb2 (Commit)

        // API to fetch sprints for a project
        // private static readonly string SprintApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_sprints/taskboard/iterations?api-version=6.0";
        private static readonly string SprintApiUrl = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/work/teamsettings/iterations?api-version=6.0";

<<<<<<< HEAD
        /// <summary>
        /// Form Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Form1_Load(object sender, EventArgs e)
        {
            await GetEpicsAsync(OrganizationName, ProjectName); //Get Epic 
            await GetFeatureAsync(OrganizationName, ProjectName);// Get Feature

        }

=======
        private async void Form1_Load(object sender, EventArgs e)
        {

            await GetEpicsAsync(OrganizationName, ProjectName);
            // await CreateEpic("First Epic Created", "Created By Anil Panwar");

            //  await callAzure();
            // await GetSprints();
        }
>>>>>>> 5236eb2 (Commit)
        /// <summary>
        /// Get EPIC list 
        /// </summary>
        /// <param name="orgName"></param>
        /// <param name="projectName"></param>
        /// <returns></returns>
        /// </summary>
        /// <param name="orgName"></param>
        /// <param name="projectName"></param>
        /// <returns></returns>
<<<<<<< HEAD
        public async Task<List<SelectListItem>> GetEpicsAsync(string orgName, string projectName)
        {
            var epicList = new List<SelectListItem>();
            string url = $"https://dev.azure.com/{orgName}/{projectName}/_apis/wit/wiql?api-version=7.1-preview.2";
            string wiqlQuery = @"{
                ""query"": ""SELECT [System.Id], [System.Title], [System.State] 
                            FROM WorkItems 
                            WHERE [System.WorkItemType] = 'Epic' 
                            AND [System.State] <> 'Closed' 
                            ORDER BY [System.Id]""
            }";
=======
        public async Task GetEpicsAsync(string orgName, string projectName)
        {
            string url = $"https://dev.azure.com/{orgName}/{projectName}/_apis/wit/wiql?api-version=7.1-preview.2";
            //string wiqlQuery = @"{ ""query"": ""Select [System.Id], [System.Title] From WorkItems Where [System.WorkItemType] = 'Epic'"" }";
            //string wiqlQuery = @"{ ""query"": ""Select [System.Id], [System.Title] From WorkItems Where [System.WorkItemType] = 'Epic'"" }";



            string wiqlQuery = @"
        {
            ""query"": ""SELECT [System.Id], [System.Title], [System.State] 
                        FROM WorkItems 
                        WHERE [System.WorkItemType] = 'Epic' 
                        AND [System.State] <> 'Closed' 
                        ORDER BY [System.Id]""
        }";
>>>>>>> 5236eb2 (Commit)

            using HttpClient client = new();
            var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{PersonalAccessToken}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = new StringContent(wiqlQuery, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);

<<<<<<< HEAD
            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject jsonResponse = JObject.Parse(responseBody);
                // Add a default option
                epicList.Add(new SelectListItem { Value = "Create", Text = "➕ Create New Epic" });
=======

            if (response.IsSuccessStatusCode)
            {
                // Read the response body
                string responseBody = await response.Content.ReadAsStringAsync();

                // Parse the response JSON
                JObject jsonResponse = JObject.Parse(responseBody);


                ArrayList arrayList = new ArrayList();
                // Loop through the work items (Epics) and print out the details
>>>>>>> 5236eb2 (Commit)

                foreach (var workItem in jsonResponse["workItems"])
                {
                    string workItemId = workItem["id"].ToString();
<<<<<<< HEAD
                    string workItemTitle = await GetEpicTitle(orgName, client, workItemId);
                    epicList.Add(new SelectListItem { Text = workItemTitle, Value = workItemId });
                }

            }
            return epicList;
        }

        /// <summary>
        /// Get Feature list 
        /// </summary>
        /// <param name="orgName"></param>
        /// <param name="projectName"></param>
        /// <returns></returns>
        public async Task<List<SelectListItem>> GetFeatureAsync(string orgName, string projectName)
        {
            var epicList = new List<SelectListItem>();
            string url = $"https://dev.azure.com/{orgName}/{projectName}/_apis/wit/wiql?api-version=7.1-preview.2";
            string wiqlQuery = @"{
                ""query"": ""SELECT [System.Id], [System.Title], [System.State] 
                            FROM WorkItems 
                            WHERE [System.WorkItemType] = 'Feature' 
                            AND [System.State] <> 'Closed' 
                            ORDER BY [System.Id]""
            }";

            using HttpClient client = new();
            var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{PersonalAccessToken}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = new StringContent(wiqlQuery, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject jsonResponse = JObject.Parse(responseBody);
                // Add a default option
                epicList.Add(new SelectListItem { Value = "Create", Text = "➕ Create New Feature" });

                foreach (var workItem in jsonResponse["workItems"])
                {
                    string workItemId = workItem["id"].ToString();
                    string workItemTitle = await GetEpicTitle(orgName, client, workItemId);
                    epicList.Add(new SelectListItem { Text = workItemTitle, Value = workItemId });
                }

            }
            return epicList;
        }

=======
                    string workItemUrl = workItem["url"].ToString();
                    string workItemTitle = await GetEpicTitle(orgName, client, workItemId);
                    arrayList.Add(workItemTitle);
                }
                arrayList.Insert(0, "<--create a new EPIC-->");
               // cmbEpic.DataSource = arrayList;

            }
        }
>>>>>>> 5236eb2 (Commit)
        /// <summary>
        /// Get Epic Title based on ID 
        /// </summary>
        /// <param name="orgName"></param>
        /// <param name="client"></param>
        /// <param name="workItemId"></param>
        /// <returns></returns>
        private static async Task<string> GetEpicTitle(string orgName, HttpClient client, string workItemId)
        {
            string workItemsUrl = $"https://dev.azure.com/{orgName}/_apis/wit/workitems?ids={workItemId}&$expand=fields&api-version=7.1-preview.3";

            // Send request to get full details of Epics
            var workItemsResponse = await client.GetAsync(workItemsUrl);
            string workItemsResult = await workItemsResponse.Content.ReadAsStringAsync();

            // Parse JSON response
            var workItemsJson = JObject.Parse(workItemsResult);
            string workItemTitle = string.Empty;
            // Print Epic Titles
            foreach (var item in workItemsJson["value"])
            {
                workItemTitle += item["fields"]["System.Title"].ToString();
            }
<<<<<<< HEAD
            return workItemTitle;
        }

        /// <summary>
        /// Bind Feature based in EPIC selection
        /// </summary>
        /// <param name="epicId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<JsonResult> GetFeaturesByEpic(string epicId)
        {
            var features = await GetFeaturesForEpicAsync(OrganizationName, ProjectName, epicId);
            return Json(features);
        }

        /// <summary>
        /// Helper method to get features for a specific Epic
        /// </summary>
        /// <param name="orgName"></param>
        /// <param name="projectName"></param>
        /// <param name="epicId"></param>
        /// <returns></returns>
        private async Task<List<SelectListItem>> GetFeaturesForEpicAsync(string orgName, string projectName, string epicId)
        {
            var featureList = new List<SelectListItem>();
            string url = $"https://dev.azure.com/{orgName}/{projectName}/_apis/wit/wiql?api-version=7.1-preview.2";
            string wiqlQuery = $@"{{
                ""query"": ""SELECT [System.Id], [System.Title], [System.State] 
                            FROM WorkItems 
                            WHERE [System.WorkItemType] = 'Feature' 
                            AND [System.State] <> 'Closed'
                            AND [System.Parent] = {epicId}
                            ORDER BY [System.Id]""
            }}";

            using HttpClient client = new();
            var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{PersonalAccessToken}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = new StringContent(wiqlQuery, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject jsonResponse = JObject.Parse(responseBody);
                featureList.Add(new SelectListItem { Value = "Create", Text = "➕ Create New Feature" });

                foreach (var workItem in jsonResponse["workItems"])
                {
                    string workItemId = workItem["id"].ToString();
                    string workItemTitle = await GetEpicTitle(orgName, client, workItemId);
                    featureList.Add(new SelectListItem { Text = workItemTitle, Value = workItemId });
                }
            }
            return featureList;
        }

        /// <summary>
        /// Creates a User Story work item in Azure DevOps under a specified Feature or Epic.
        /// </summary>
        /// <param name="title">The title of the User Story.</param>
        /// <param name="description">The description of the User Story.</param>
        /// <param name="parentId">The work item ID of the parent Feature or Epic. If null or empty, no parent is linked.</param>
        /// <param name="assignedTo">The user to assign the User Story to.</param>
        /// <returns>The ID of the newly created User Story, or 0 if creation fails.</returns>
        private async Task<int> CreateUserStoryAsync(string title, string description, string parentId, string assignedTo, string acceptance_Creatria, int storypoints, int priority)
        {
            string relatedUserStoryId = string.Empty; // Set this if you want to link to another User Story

            relatedUserStoryId = "117";
            var patchDocument = new List<object>
            {
                new { op = "add", path = "/fields/System.Title", value = title },
                new { op = "add", path = "/fields/System.Description", value = description.TrimStart() },
                new { op = "add", path = "/fields/System.AssignedTo", value = assignedTo },
                new { op = "add", path = "/fields/Microsoft.VSTS.Common.AcceptanceCriteria", value = acceptance_Creatria },
                new { op = "add", path = "/fields/Microsoft.VSTS.Scheduling.StoryPoints", value = 1},
                new { op = "add", path = "/fields/Microsoft.VSTS.Common.Priority", value = 1},
                new {
                    op = "add",
                    path = "/relations/-",
                    value = new {
                        rel = "System.LinkTypes.Hierarchy-Reverse",
                        url = $"https://dev.azure.com/{OrganizationName}/_apis/wit/workItems/{parentId}"
                    }
                }
            };
            if (!string.IsNullOrEmpty(relatedUserStoryId))
            {
                patchDocument.Add(new
                {
                    op = "add",
                    path = "/relations/-",
                    value = new
                    {
                        rel = "System.LinkTypes.Related",
                        url = $"https://dev.azure.com/{OrganizationName}/_apis/wit/workItems/{relatedUserStoryId}"
                    }
                });
            }

            using var client = new HttpClient();
            var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{PersonalAccessToken}"));
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var content = new StringContent(Newtonsoft.Json.JsonConvert.SerializeObject(patchDocument), Encoding.UTF8, "application/json-patch+json");
            var method = new HttpMethod("PATCH");
            var request = new HttpRequestMessage(method, $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workitems/$User Story?api-version=7.1-preview.3")
            {
                Content = content
            };

            var response = await client.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadAsStringAsync();
                var json = JObject.Parse(result);
                return json["id"]?.Value<int>() ?? 0;
            }
            return 0;
        }

        /// <summary>
        /// Create task under user story
        /// </summary>
        /// <param name="title"></param>
        /// <param name="description"></param>
        /// <param name="userStoryId"></param>
        /// <returns></returns>
        //private async Task<int> CreateTaskAsync(string title, string description, int userStoryId)
        //{
        //    var url = $"https://dev.azure.com/{OrganizationName}/{ProjectName}/_apis/wit/workitems/$Task?api-version=7.1-preview.3";
        //        var patchDocument = new[]
        //        {
        //            new { op = "add", path = "/fields/System.Title", value = title },
        //            new { op = "add", path = "/fields/System.Description", value = description },
        //            new {
        //                op = "add",
        //                path = "/relations/-",
        //                value = new {
        //                    rel = "System.LinkTypes.Hierarchy-Reverse",
        //                    url = $"https://dev.azure.com/{OrganizationName}/_apis/wit/workItems/{userStoryId}"
        //                }
        //            }
        //        };

        //    using var client = new HttpClient();
        //    var authToken = Convert.ToBase64String(Encoding.ASCII.GetBytes($":{PersonalAccessToken}"));
        //    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

        //    var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(patchDocument), Encoding.UTF8, "application/json-patch+json");
        //    var response = await client.PostAsync(url, content);

        //    if (response.IsSuccessStatusCode)
        //    {
        //        var result = await response.Content.ReadAsStringAsync();
        //        var json = JObject.Parse(result);
        //        return (int)json["id"];
        //    }
        //    return 0;
        //}
        
        private static string Formating(string description)
        {
            // Existing patterns...

            // Ensure inline "1. ", "2. ", ... become line-start items
            var breakBeforeInlineNumberDot = new Regex(@"(?<!^)(?<!##)\s*(?=\d+\.\s)", RegexOptions.Singleline);
            // Ensure inline hyphen bullets become line-start items
            var breakBeforeInlineHyphen = new Regex(@"(?<!^)(?<!##)\s*(?=-\s)", RegexOptions.Singleline);
            // Break around triple-dash separators
            var breakAroundEmDash = new Regex(@"\s*---\s*", RegexOptions.Singleline);

            string preProcessed = description ?? string.Empty;

            // Add breaks for inline numbered steps and bullets
            preProcessed = breakBeforeInlineNumberDot.Replace(preProcessed, "##");
            preProcessed = breakBeforeInlineHyphen.Replace(preProcessed, "##");
            // Normalize em-dash separators to breaks
            preProcessed = breakAroundEmDash.Replace(preProcessed, "##");

            // Keep your existing logic after this point (bolding, existing breaks, encoding, replacements)...
            // [rest of your current method body remains unchanged]

            // Encode and materialize placeholders (existing logic)
            string descriptionHtml = $"<p>{System.Net.WebUtility.HtmlEncode(preProcessed)}</p>"
                .Replace("##", "<br/>");
            return descriptionHtml;
        }
        private static string[] SplitAfterAcceptanceCriteria(string UserStoryDescription)
        {
            if (string.IsNullOrEmpty(UserStoryDescription))
            {
                return new[] { string.Empty, string.Empty };
            }

            // Consider common variants that may exist before/after formatting:
            // - Raw markdown marker: "Acceptance Criteria**"
            // - Formatted HTML bold: "<strong>Acceptance Criteria</strong>"
            // - With trailing colon variants
            var patterns = new[]
            {
                @"Acceptance\s*Criteria\*\*",                                 // markdown bold suffix
                @"<strong>\s*Acceptance\s*Criteria\s*</strong>\s*:? ",        // strong html, optional colon
                @"Acceptance\s*Criteria\s*:? "                                // plain text, optional colon
            };

            // Normalize for robust search
            var haystack = UserStoryDescription;
            var earliestIndex = -1;
            var earliestLength = 0;

            foreach (var pattern in patterns)
            {
                var match = Regex.Match(haystack, pattern, RegexOptions.IgnoreCase | RegexOptions.Singleline);
                if (match.Success)
                {
                    var idx = match.Index;
                    if (earliestIndex == -1 || idx < earliestIndex)
                    {
                        earliestIndex = idx;
                        earliestLength = match.Length;
                    }
                }
            }

            if (earliestIndex == -1)
            {
                // Marker not found; return original and empty tail.
                return new[] { UserStoryDescription, string.Empty };
            }

            var splitPoint = earliestIndex + earliestLength;
            if (splitPoint >= haystack.Length)
            {
                return new[] { UserStoryDescription, string.Empty };
            }

            var before = haystack.Substring(0, splitPoint);
            var after = haystack.Substring(splitPoint);
            return new[] { before, after };
        }
=======

            return workItemTitle;
        }


        //private async void button1_Click(object sender, EventArgs e)
        //{
        //    // await CreateEpic("AP First Test Automatic EPIC", "First Epic By AP");
        //    await CreateFeatureAsChildOfEpic(OrganizationName, ProjectName, PersonalAccessToken, 60, "First Feature for first EPIC written By AP");
        //}
>>>>>>> 5236eb2 (Commit)
    }
}
