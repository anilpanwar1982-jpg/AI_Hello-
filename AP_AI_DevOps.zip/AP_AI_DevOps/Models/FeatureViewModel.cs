public class FeatureViewModel
{
    public string Title { get; set; }
    public string Description { get; set; }
    public int EpicId { get; set; }
}

