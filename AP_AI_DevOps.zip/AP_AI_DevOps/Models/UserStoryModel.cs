﻿namespace AP_AI_DevOps.Models
{
    // Model for User Story
    public class UserStoryModel
    {
        public string UserStoryTitle { get; set; }
        public string UserStoryDescription { get; set; }
        public string? ParentId { get; set; }
        public string? AssignedTo { get; set; }
        public string? AcceptanceCriteria { get; set; } // Corrected property name
        public int Priority { get; set; } // Added property
        public int StoryPoints { get; set; } // Added property
    }
}
