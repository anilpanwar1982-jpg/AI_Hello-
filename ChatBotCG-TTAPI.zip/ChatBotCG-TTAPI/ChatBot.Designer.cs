﻿namespace ChatBotCG_TTAPI
{
    partial class APChatBot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            sendButton = new Button();
            messageInputRichTextBox = new RichTextBox();
            chatHistoryRichTextBox = new RichTextBox();
            cmboModel = new ComboBox();
            cmboStream = new ComboBox();
            pnlTop = new Panel();
            lblResponseType = new Label();
            lblModel = new Label();
            pnlBottom = new Panel();
            pnlTop.SuspendLayout();
            pnlBottom.SuspendLayout();
            SuspendLayout();
            // 
            // sendButton
            // 
            sendButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            sendButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            sendButton.Location = new Point(1162, 15);
            sendButton.Margin = new Padding(5, 6, 5, 6);
            sendButton.Name = "sendButton";
            sendButton.Size = new Size(152, 92);
            sendButton.TabIndex = 1;
            sendButton.Text = "Send";
            sendButton.UseVisualStyleBackColor = true;
            sendButton.Click += sendButton_Click;
            // 
            // messageInputRichTextBox
            // 
            messageInputRichTextBox.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            messageInputRichTextBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            messageInputRichTextBox.Location = new Point(20, 15);
            messageInputRichTextBox.Margin = new Padding(5, 6, 5, 6);
            messageInputRichTextBox.Name = "messageInputRichTextBox";
            messageInputRichTextBox.Size = new Size(1129, 89);
            messageInputRichTextBox.TabIndex = 0;
            messageInputRichTextBox.Text = "";
            // 
            // chatHistoryRichTextBox
            // 
            chatHistoryRichTextBox.BackColor = SystemColors.ControlLightLight;
            chatHistoryRichTextBox.Dock = DockStyle.Fill;
            chatHistoryRichTextBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chatHistoryRichTextBox.Location = new Point(0, 87);
            chatHistoryRichTextBox.Margin = new Padding(5, 6, 5, 6);
            chatHistoryRichTextBox.Name = "chatHistoryRichTextBox";
            chatHistoryRichTextBox.ReadOnly = true;
            chatHistoryRichTextBox.Size = new Size(1333, 653);
            chatHistoryRichTextBox.TabIndex = 2;
            chatHistoryRichTextBox.Text = "";
            // 
            // cmboModel
            // 
            cmboModel.DropDownStyle = ComboBoxStyle.DropDownList;
            cmboModel.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmboModel.FormattingEnabled = true;
            cmboModel.Items.AddRange(new object[] { "gpt-4o", "gpt-5.1-chat", "gpt-5-mini", "text-embedding-3-large" });
            cmboModel.Location = new Point(152, 23);
            cmboModel.Margin = new Padding(5, 6, 5, 6);
            cmboModel.Name = "cmboModel";
            cmboModel.Size = new Size(247, 33);
            cmboModel.TabIndex = 3;
            cmboModel.SelectedIndexChanged += cmboModel_SelectedIndexChanged;
            // 
            // cmboStream
            // 
            cmboStream.DropDownStyle = ComboBoxStyle.DropDownList;
            cmboStream.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmboStream.FormattingEnabled = true;
            cmboStream.Items.AddRange(new object[] { "Normal Model Response", "Stream Model Response", "Response With History", "Embeding Generator", "Embeding Generator-RAG" });
            cmboStream.Location = new Point(640, 23);
            cmboStream.Margin = new Padding(5, 6, 5, 6);
            cmboStream.Name = "cmboStream";
            cmboStream.Size = new Size(297, 33);
            cmboStream.TabIndex = 4;
            cmboStream.SelectedIndexChanged += cmboStream_SelectedIndexChanged;
            // 
            // pnlTop
            // 
            pnlTop.Controls.Add(lblResponseType);
            pnlTop.Controls.Add(lblModel);
            pnlTop.Controls.Add(cmboModel);
            pnlTop.Controls.Add(cmboStream);
            pnlTop.Dock = DockStyle.Top;
            pnlTop.Location = new Point(0, 0);
            pnlTop.Margin = new Padding(5, 6, 5, 6);
            pnlTop.Name = "pnlTop";
            pnlTop.Size = new Size(1333, 87);
            pnlTop.TabIndex = 5;
            // 
            // lblResponseType
            // 
            lblResponseType.AutoSize = true;
            lblResponseType.Font = new Font("Segoe UI", 9F);
            lblResponseType.Location = new Point(412, 29);
            lblResponseType.Margin = new Padding(5, 0, 5, 0);
            lblResponseType.Name = "lblResponseType";
            lblResponseType.Size = new Size(185, 25);
            lblResponseType.TabIndex = 6;
            lblResponseType.Text = "Select Response Type:";
            // 
            // lblModel
            // 
            lblModel.AutoSize = true;
            lblModel.Font = new Font("Segoe UI", 9F);
            lblModel.Location = new Point(20, 29);
            lblModel.Margin = new Padding(5, 0, 5, 0);
            lblModel.Name = "lblModel";
            lblModel.Size = new Size(118, 25);
            lblModel.TabIndex = 5;
            lblModel.Text = "Select Model:";
            // 
            // pnlBottom
            // 
            pnlBottom.Controls.Add(messageInputRichTextBox);
            pnlBottom.Controls.Add(sendButton);
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Location = new Point(0, 740);
            pnlBottom.Margin = new Padding(5, 6, 5, 6);
            pnlBottom.Name = "pnlBottom";
            pnlBottom.Size = new Size(1333, 125);
            pnlBottom.TabIndex = 6;
            // 
            // APChatBot
            // 
            AcceptButton = sendButton;
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1333, 865);
            Controls.Add(chatHistoryRichTextBox);
            Controls.Add(pnlTop);
            Controls.Add(pnlBottom);
            Margin = new Padding(5, 6, 5, 6);
            Name = "APChatBot";
            Text = "APChatBot";
            Load += APChatBot_Load;
            pnlTop.ResumeLayout(false);
            pnlTop.PerformLayout();
            pnlBottom.ResumeLayout(false);
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button sendButton;
        private System.Windows.Forms.RichTextBox messageInputRichTextBox;
        private System.Windows.Forms.RichTextBox chatHistoryRichTextBox;
        private System.Windows.Forms.ComboBox cmboModel;
        private System.Windows.Forms.ComboBox cmboStream;
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblResponseType;
    }
}