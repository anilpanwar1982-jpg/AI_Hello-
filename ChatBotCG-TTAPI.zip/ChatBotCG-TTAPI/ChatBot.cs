using Azure;
using Azure.AI.OpenAI;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.VectorData;
using Microsoft.SemanticKernel.Connectors.InMemory;
using OpenAI.Chat;
using System.ClientModel;
using ChatMessage = OpenAI.Chat.ChatMessage;
using Microsoft.SemanticKernel.Connectors.AzureAISearch;

namespace ChatBotCG_TTAPI
{
    public partial class APChatBot : Form
    {
        string selectedModelValue = string.Empty;
        string selectResponseType = string.Empty;
        private static readonly IConfiguration _configuration;
        private readonly List<ChatMessage> historyChat = new();

        static APChatBot()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("AppSettings.json", optional: false, reloadOnChange: true);
            _configuration = builder.Build();
        }
        public APChatBot()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Main Srteming method    
        /// </summary>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        async Task<string> StreamingChat(string LineofCode)
        {
            string modelToUse = selectedModelValue;
            if (string.IsNullOrEmpty(modelToUse))
            {
                MessageBox.Show("You have not selected any model, so the default model 'gpt-4o' will be used.");
                modelToUse = "gpt-4o";
            }

            ChatClient? chatClient = GetChatClient(modelToUse);
            AzureOpenAIClient? azureOpenAIClient = GetAzureOpenAIClient(modelToUse);

            if (chatClient == null)
            {
                MessageBox.Show("Failed to initialize chat client for the selected model.");
                return "Error: Chat client is not initialized.";
            }


            string responseType = selectResponseType;
            if (string.IsNullOrEmpty(responseType))
            {
                MessageBox.Show("You have not selected any Response type, so the default 'Normal Model Response' will be used.");
                responseType = "Normal Model Response";
            }


            switch (responseType)
            {
                case "Stream Model Response":
                    return StreamModelResponse(chatClient, LineofCode);
                case "Response With History":
                    return ModelResponsewithHistory(chatClient, LineofCode);
                case "Normal Model Response":
                    return await NormalModelResponse(chatClient, LineofCode);
                case "Embeding Generator":
                    if (azureOpenAIClient == null)
                    {
                        MessageBox.Show("Failed to initialize AzureOpenAIClient for the selected model.");
                        return "Error: AzureOpenAIClient is not initialized.";
                    }
                    if (modelToUse == "text-embedding-3-large")
                    {
                        return await GetEmbedingClientResultAsync(azureOpenAIClient!, LineofCode, selectedModelValue);
                    }
                    // Add a break or return to prevent fall-through
                    return "Error: Embedding Generator selected but model is not 'text-embedding-3-large'.";
                case "Embeding Generator-RAG":

                    if (modelToUse == "text-embedding-3-large")
                    {
                        return await RAGResponseAsync(azureOpenAIClient!, LineofCode, selectedModelValue, "gpt-5.1-chat-rag");
                    }
                    return "Error: Embedding Generator RAG selected but model is not 'text-embedding-3-large'.";

                default:
                    return "Error: No valid response type selected.";
            }
        }
        /// <summary>
        /// RAG Response for a internal Doc
        /// </summary>
        /// <param name="azureOpenAIClient"></param>
        /// <param name="LineofCode"></param>
        /// <param name="modelName"></param>
        /// <param name="ragModel"></param>
        /// <returns></returns>
        private async Task<string> RAGResponseAsync(AzureOpenAIClient azureOpenAIClient, string LineofCode, string modelName, string ragModel)
        {
            string strmsg = string.Empty;
            var topResults = new List<CloudService>();
            IEmbeddingGenerator<string, Embedding<float>> generator = azureOpenAIClient.GetEmbeddingClient(modelName).AsIEmbeddingGenerator();

            IEnumerable<CloudService> cloudServices = new List<CloudService>
            {
                new CloudService { Key=0,Name = "Azure App service",Description ="Host .net, Java, Node.js, and Python web Development,we API development and deployment" },
                new CloudService { Key=1,Name = "Azure Functions",Description ="Process events with serverless code,Scale on-demand,Pay only for the resources you consume" },
                new CloudService { Key=2,Name = "Azure Kubernetes Service",Description ="Simplify the deployment, management, and operations of Kubernetes" },
                new CloudService { Key=3,Name = "Azure Virtual Machines",Description ="Create Linux and Windows virtual machines in seconds,Supports a wide range of sizes and configurations" },
                new CloudService { Key=4,Name = "Azure Blob SItorage",Description ="Massively scalable object storage for unstructured data,Optimized for storing large amounts of unstructured data" },
                new CloudService { Key=5,Name = "Azure SQL Database",Description ="Managed relational database service with built-in intelligence,Scales on-demand with high availability" },
            };

            var vectorStore = new InMemoryVectorStore();

            VectorStoreCollection<int, CloudService> cloudServiceStore = vectorStore.GetCollection<int, CloudService>("cloudServices");
            await cloudServiceStore.EnsureCollectionExistsAsync();

            foreach (CloudService service in cloudServices)
            {
                service.Vector = await generator.GenerateVectorAsync(service.Description);
                await cloudServiceStore.UpsertAsync(service);
            }

            ReadOnlyMemory<float> queryEmbeding = await generator.GenerateVectorAsync(LineofCode);

            IAsyncEnumerable<VectorSearchResult<CloudService>> results = cloudServiceStore.SearchAsync(queryEmbeding, top: 1);

            await foreach (VectorSearchResult<CloudService> result in results)
            {
                if (result.Score > .40)
                {
                    strmsg +=
                    $"Cloud Service Name: {result.Record.Name}{Environment.NewLine}" +
                    $"Description: {result.Record.Description}{Environment.NewLine}" +
                    $"Vector: {result.Score}{Environment.NewLine}";
                    topResults.Add(result.Record);
                }
            }

            if (topResults.Count > 0)
            {
                string context = string.Join('\n', topResults.Select(r => $"Service:{r.Name}\n{r.Description}"));

                string ragprompt = $"""
                    You are an Azure expert. Use only the following Service dscriptions to answer the question.
                    Context:  {context}
                    Question: {LineofCode}
                    Answer Brifly mention which service you recomend:
                    """;

                ChatClient? chatClientRAG = GetChatClient(ragModel);
                if (chatClientRAG == null)
                {
                    return "Error: Chat client for RAG model is not initialized.";
                }

                var messages = new[]
                {
                    new UserChatMessage(ragprompt)
                };

                var response = await chatClientRAG.CompleteChatAsync(messages, new ChatCompletionOptions { MaxOutputTokenCount = 400 });

                return response.Value.Content[0].Text;
            }
            return strmsg;
        }

        /// <summary>
        /// This method is used to send a line of code to the OpenAI API and get a response.
        /// </summary>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        private ChatClient? GetChatClient(string modelName)
        {
            string? endpointUrl = _configuration[$"AzureOpenAI:{modelName}:Endpoint"];
            string? apiKey = _configuration[$"AzureOpenAI:{modelName}:ApiKey"];

            if (string.IsNullOrEmpty(endpointUrl) || string.IsNullOrEmpty(apiKey))
            {
                MessageBox.Show($"Configuration for model '{modelName}' not found in appsettings.json.");
                return null;
            }
            Uri endpoint = new(endpointUrl);
            AzureKeyCredential credential = new AzureKeyCredential(apiKey);
            AzureOpenAIClient azureClient = new AzureOpenAIClient(endpoint, credential);
            ChatClient chatClient = azureClient.GetChatClient(modelName);
            return chatClient;
        }

        /// <summary>
        /// This method is used to send a line of code to the OpenAI API and get a response.
        /// </summary>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        private AzureOpenAIClient? GetAzureOpenAIClient(string modelName)
        {
            string? endpointUrl = _configuration[$"AzureOpenAI:{modelName}:Endpoint"];
            string? apiKey = _configuration[$"AzureOpenAI:{modelName}:ApiKey"];

            if (string.IsNullOrEmpty(endpointUrl) || string.IsNullOrEmpty(apiKey))
            {
                MessageBox.Show($"Configuration for model '{modelName}' not found in appsettings.json.");
                return null;
            }

            Uri endpoint = new(endpointUrl);
            AzureKeyCredential credential = new(apiKey);
            AzureOpenAIClient azureClient = new(endpoint, credential);
            return azureClient;
        }

        /// <summary>
        /// Private async method
        /// </summary>
        /// <param name="chatClient"></param>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        private async Task<string> NormalModelResponse(ChatClient chatClient, string LineofCode)
        {
            var chatCompletionOptions = new ChatCompletionOptions()
            {
                MaxOutputTokenCount = 4096,
                Temperature = 1.0f,
                TopP = 1.0f,
            };

            List<ChatMessage> messages = new List<ChatMessage>
            {
                new UserChatMessage(LineofCode),
            };

            var response = await chatClient.CompleteChatAsync(messages);
            return response.Value.Content[0].Text;
        }

        /// <summary>
        /// ModelResponsewithHistory
        /// </summary>
        /// <param name="chatClient"></param>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        private string ModelResponsewithHistory(ChatClient chatClient, string LineofCode)
        {
            var requestOptions = new ChatCompletionOptions()
            {
                MaxOutputTokenCount = 4096,
                Temperature = 1.0f,
                TopP = 1.0f,
            };

            List<ChatMessage> messages = new List<ChatMessage>
            {
                new UserChatMessage(LineofCode),
            };
            historyChat.Add(new UserChatMessage("User", LineofCode));
            var response = chatClient.CompleteChatAsync(historyChat);
            return response.Result.Value.Content[0].Text;
        }

        /// <summary>
        /// StreamModelResponse
        /// </summary>
        /// <param name="chatClient"></param>
        /// <param name="LineofCode"></param>
        /// <returns></returns>
        private string StreamModelResponse(ChatClient chatClient, string LineofCode)
        {
            string strmsg = string.Empty;
            historyChat.Add(new UserChatMessage(LineofCode));
            CollectionResult<StreamingChatCompletionUpdate> completionUpdates = chatClient.CompleteChatStreaming(historyChat.ToArray());

            foreach (StreamingChatCompletionUpdate completionUpdate in completionUpdates)
            {
                foreach (ChatMessageContentPart contentPart in completionUpdate.ContentUpdate)
                {
                    strmsg += contentPart.Text;
                }
            }

            historyChat.Add(new AssistantChatMessage(strmsg));

            return $" Streaming Chat Assistant:{strmsg}";
        }

        private async Task<string> GetEmbedingClientResultAsync(AzureOpenAIClient azureOpenAIClient, string LineofCode, string modelName)
        {

            string strmsg = string.Empty;
            var topResults = new List<CloudService>();
            IEmbeddingGenerator<string, Embedding<float>> generator = azureOpenAIClient.GetEmbeddingClient(modelName).AsIEmbeddingGenerator();

            IEnumerable<CloudService> cloudServices = new List<CloudService>
            {
                new CloudService { Key=0,Name = "Azure App service",Description ="Host .net, Java, Node.js, and Python web Development,we API development and deployment" },
                new CloudService { Key=1,Name = "Azure Functions",Description ="Process events with serverless code,Scale on-demand,Pay only for the resources you consume" },
                new CloudService { Key=2,Name = "Azure Kubernetes Service",Description ="Simplify the deployment, management, and operations of Kubernetes" },
                new CloudService { Key=3,Name = "Azure Virtual Machines",Description ="Create Linux and Windows virtual machines in seconds,Supports a wide range of sizes and configurations" },
                new CloudService { Key=4,Name = "Azure Blob SItorage",Description ="Massively scalable object storage for unstructured data,Optimized for storing large amounts of unstructured data" },
                new CloudService { Key=5,Name = "Azure SQL Database",Description ="Managed relational database service with built-in intelligence,Scales on-demand with high availability" },
            };

            var vectorStore = new InMemoryVectorStore();

            VectorStoreCollection<int, CloudService> cloudServiceStore = vectorStore.GetCollection<int, CloudService>("cloudServices");
            await cloudServiceStore.EnsureCollectionExistsAsync();

            foreach (CloudService service in cloudServices)
            {
                service.Vector = await generator.GenerateVectorAsync(service.Description);
                await cloudServiceStore.UpsertAsync(service);
            }

            ReadOnlyMemory<float> queryEmbeding = await generator.GenerateVectorAsync(LineofCode);

            IAsyncEnumerable<VectorSearchResult<CloudService>> results = cloudServiceStore.SearchAsync(queryEmbeding, top: 2);

            await foreach (VectorSearchResult<CloudService> result in results)
            {
                if (result.Score > .40)
                {
                    strmsg +=
                    $"Cloud Service Name: {result.Record.Name}{Environment.NewLine}" +
                    $"Description: {result.Record.Description}{Environment.NewLine}" +
                    $"Vector: {result.Score}{Environment.NewLine}";
                    topResults.Add(result.Record);
                    // Implement the RAG logic here if RAG category is selected
                }
            }

            if (topResults.Count > 0)
            {
                string context = string.Join('\n', topResults.Select(r => $"Service:{r.Name}\n{r.Description}"));

                string ragprompt = $"""
                    Question: {LineofCode}
                    Context:  {context}                    
                    """;
                return ragprompt;
            }
            else
                return strmsg = "No relevent record found in this score";
        }

        /// <summary>
        /// Get selected model from combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmboModel_SelectedIndexChanged(object sender, EventArgs e)
        {
            var cmboModel = sender as ComboBox;
            // Check if the cast was successful and an item is selected
            if (cmboModel != null && cmboModel.SelectedItem != null)
            {
                // Get the selected item and convert it to a string
                selectedModelValue = cmboModel.SelectedItem.ToString()!;
            }
        }

        /// <summary>
        /// Get selected response type from combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmboStream_SelectedIndexChanged(object sender, EventArgs e)
        {
            var cmboModel = sender as ComboBox;
            // Check if the cast was successful and an item is selected
            if (cmboModel != null && cmboModel.SelectedItem != null)
            {
                // Get the selected item and convert it to a string
                selectResponseType = cmboModel.SelectedItem.ToString()!;
            }

        }

        /// <summary>
        ///  sending details to OpenAI API and getting response from it.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void sendButton_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(messageInputRichTextBox.Text))
            {
                string response = await StreamingChat(messageInputRichTextBox.Text);
                chatHistoryRichTextBox.AppendText($"\n{DateTime.Now}\n{response}");
            }
            else
            {
                chatHistoryRichTextBox.AppendText("Please write the question, How can I help you?");
            }
            RichTextBox_TextChanged();
            messageInputRichTextBox.Clear();
        }

        /// <summary>
        /// Richtext box text change event
        /// </summary>
        private void RichTextBox_TextChanged()
        {
            // Check if text length exceeds 10000
            if (chatHistoryRichTextBox.Text.Length > 10000)
            {
                // Show a message box asking the user
                var result = MessageBox.Show(
                    "The text length has exceeded 10,000 characters. Do you want to clear the content?",
                    "Text Length Exceeded",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                // If the user clicks Yes, clear the content
                if (result == DialogResult.Yes)
                {
                    chatHistoryRichTextBox.Clear();
                }
            }
        }

        /// <summary>
        /// Form Load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void APChatBot_Load(object sender, EventArgs e)
        {
            cmboModel.SelectedIndex = 0;
            cmboStream.SelectedIndex = 0;
        }
    }
}
