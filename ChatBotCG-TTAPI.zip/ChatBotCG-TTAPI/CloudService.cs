﻿using Microsoft.Extensions.VectorData;

namespace ChatBotCG_TTAPI
{
    internal class CloudService
    {
        [VectorStoreKey]
        public int Key { get; set; }
        [VectorStoreData]
        public string? Name { get; set; }

        [VectorStoreData]
        public required string Description { get; set; }

        [VectorStoreVector(Dimensions: 3072, DistanceFunction = DistanceFunction.CosineSimilarity)]
        public ReadOnlyMemory<float> Vector { get; set; }
    }
}
